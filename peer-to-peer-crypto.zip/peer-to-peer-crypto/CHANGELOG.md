## 1.12.1 [2025-07-28]
- Updated Description


## 1.12.0 [2025-07-22]
- Continued Git Changes


## 1.11.1 [2025-06-14]
- Continued Bug Fixes 

## 1.11.0 [2025-06-14]
- Updated updater

## 1.10.0 [2025-06-14]
- Updated Description
- Updated Address Field in Settings

## 1.0.9 [2025-06-14]
- Removed $50 minimum for checkout option to appear
- Added Test API connection button in settings

## 1.0.8 [2025-04-29]
- Added $50 minimum for checkout option to appear
- Added Customer Name to Payload to backend Database for tracking purposes.

## 1.0.7 [2025-04-29]
- Added API authentication for call back of updating order status to "Processing"

## 1.0.6 [2025-04-24]
- Removed some unused variables in settings
- Added a wallet address field to settings.
- Updated Create Order API call to use authentication attributes in settings.php. Verified by updated back end scripts. This will also pull a wallet address from our database and add it to the order. 
- Removed Unused Code

## 1.0.5 [2025-04-23]
- Removed "credit" terminology. 

## 1.0.4 [2025-04-23]
- Updated Name of Plugin to just 'peer to peer Crypto'

## 0.0.2 [2025-04-12]

- Fixed Updater Script


## 0.0.1 [2025-04-12]

- Updated order status to initially be "on hold"
